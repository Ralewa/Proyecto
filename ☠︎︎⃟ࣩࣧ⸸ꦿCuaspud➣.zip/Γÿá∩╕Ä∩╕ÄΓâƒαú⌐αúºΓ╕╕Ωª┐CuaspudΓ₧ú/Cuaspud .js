let count = 0;

function incrementarContador() {
  count++;
  actualizarContador();
}

function actualizarContador() {
  const contadorElemento = document.getElementById('contador');
  contadorElemento.textContent = count;
}

